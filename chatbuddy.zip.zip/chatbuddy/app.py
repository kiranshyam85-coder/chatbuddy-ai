from flask import Flask, render_template, request, jsonify
import requests, random, os
from gtts import gTTS
import threading

app = Flask(__name__)

WOLFRAM_APP_ID = 'V67P4A894P'

greetings = ["hi", "hello", "nice to meet you", "How can I help you?"]
farewells = ["bye", "goodbye", "take care"]


def wolfram_answer(query):
    try:
        url = f"https://api.wolframalpha.com/v1/result?appid={WOLFRAM_APP_ID}&i={query}"
        res = requests.get(url)
        if res.status_code == 200 and "did not understand" not in res.text:
            return f"Wolfram: {res.text}"
    except Exception as e:
        print("Wolfram error:", e)
    return None


def get_joke():
    try:
        res = requests.get("https://v2.jokeapi.dev/joke/Any")
        data = res.json()
        if data['type'] == 'single':
            return data['joke']
        else:
            return f"{data['setup']}...{data['delivery']}"
    except Exception as e:
        print("Joke error:", e)
        return "I tried to get a joke but failed."


def speak(text):
    try:
        tts = gTTS(text=text, lang='en')
        if not os.path.exists("static"):
            os.mkdir("static")
        tts.save("static/voice.mp3")
    except Exception as e:
        print("TTS error:", e)


def get_response(user_input):
    text = user_input.lower().strip()
    if "hello" in text or "hi" in text:
        return random.choice(greetings)
    if "bye" in text:
        return random.choice(farewells)
    if "who are you" in text or "what are you" in text:
        return "I am ChatBuddy V5."
    if "who made you" in text:
        return "I was made by a student."
    if "joke" in text or "funny" in text:
        return get_joke()

    wolfram_res = wolfram_answer(user_input)
    if wolfram_res:
        return wolfram_res

    return "Hmmm... I’ll find out soon."


@app.route("/")
def home():
    return render_template("index.html")


@app.route("/chat", methods=["POST"])
def chat():
    user_input = request.json["message"]
    response = get_response(user_input)

    # Generate speech in a background thread
    threading.Thread(target=speak, args=(response,)).start()

    return jsonify({"response": response, "voice": "/static/voice.mp3"})


if __name__ == "__main__":
    if not os.path.exists("static"):
        os.mkdir("static")
    app.run(debug=True)
