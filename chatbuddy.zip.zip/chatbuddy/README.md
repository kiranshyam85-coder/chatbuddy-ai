#Chatbuddy
An ai chatbot made with Python(Flask) and HTML that can talk,tell jokes,answer question and speak using gTTs(google text to speech)

##Features
-Speak responses
-Tells jokes
-HTML+Flask interface
-Answers questions using wolfram alpha

##How to run
1. Install required libraries:```bash 
pip install -r requirements.txt

2.Run the app
python app.py

3.open your browser and go to: http://127.0.0.1:5000